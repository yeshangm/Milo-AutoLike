package com.example.autolike;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class LikeAccessibilityService extends AccessibilityService {
    private static LikeAccessibilityService instance;
    private static int tapX=900, tapY=1500, tapsPerSecond=3, durationMinutes=30;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private long stopAt;
    private int count = 0;

    public static void config(int x, int y, int speed, int minutes) {
        tapX=x; tapY=y; tapsPerSecond=speed; durationMinutes=minutes;
    }
    public static void startTapping() {
        if (instance != null) instance.begin();
    }
    public static void stopTapping() {
        if (instance != null) instance.stop();
    }
    public static boolean isReady() { return instance != null; }

    @Override public void onServiceConnected() { instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() { stop(); }

    private void begin() {
        if (running) return;
        running=true; count=0; stopAt=System.currentTimeMillis()+durationMinutes*60_000L;
        tick();
    }
    private void stop() { running=false; handler.removeCallbacksAndMessages(null); }
    private void tick() {
        if (!running) return;
        if (System.currentTimeMillis() >= stopAt) { stop(); OverlayService.setRunning(false); return; }
        Path path = new Path(); path.moveTo(tapX, tapY);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0, 45);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
        count++;
        handler.postDelayed(this::tick, Math.max(200, 1000 / tapsPerSecond));
    }
    @Override public void onDestroy() { stop(); instance=null; super.onDestroy(); }
}
