package com.example.autolike;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.*;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {
    private WindowManager wm;
    private View bubble;
    private WindowManager.LayoutParams params;
    private boolean running=false;
    private float downX, downY;
    private int startX, startY;

    @Override public void onCreate() {
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        TextView v=new TextView(this);
        v.setText("赞");
        v.setTextColor(Color.WHITE);
        v.setTextSize(16);
        v.setGravity(Gravity.CENTER);
        GradientDrawable bg=new GradientDrawable();
        bg.setColor(0xCCEA4B68); bg.setShape(GradientDrawable.OVAL);
        v.setBackground(bg);
        params=new WindowManager.LayoutParams(58,58,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;
        params.x=20; params.y=300;
        bubble=v;
        v.setOnTouchListener((view,event)->{
            switch(event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX=event.getRawX(); downY=event.getRawY();
                    startX=params.x; startY=params.y; return true;
                case MotionEvent.ACTION_MOVE:
                    params.x=startX+(int)(event.getRawX()-downX);
                    params.y=startY+(int)(event.getRawY()-downY);
                    wm.updateViewLayout(bubble,params); return true;
                case MotionEvent.ACTION_UP:
                    float dx=Math.abs(event.getRawX()-downX), dy=Math.abs(event.getRawY()-downY);
                    if(dx<8 && dy<8) toggle();
                    return true;
            }
            return true;
        });
        wm.addView(bubble,params);
    }
    private void toggle() {
        if(running) {
            LikeAccessibilityService.stopTapping(); setRunning(false);
            Toast.makeText(this,"已停止点赞",Toast.LENGTH_SHORT).show();
        } else if(!LikeAccessibilityService.isReady()) {
            Toast.makeText(this,"请先在设置中开启本应用无障碍服务",Toast.LENGTH_LONG).show();
        } else {
            running=true; bubble.setAlpha(1f);
            LikeAccessibilityService.startTapping();
            Toast.makeText(this,"开始自动点赞；再次点击停止",Toast.LENGTH_SHORT).show();
        }
    }
    public static OverlayService current;
    public static void setRunning(boolean value) {
        if (current != null) {
            current.running = value;
            if (current.bubble instanceof TextView) {
                ((TextView) current.bubble).setText(value ? "停" : "赞");
            }
        }
    }
    @Override public int onStartCommand(Intent i,int flags,int id) { return START_NOT_STICKY; }
    @Override public void onDestroy() { LikeAccessibilityService.stopTapping(); current=null; if(bubble!=null) wm.removeView(bubble); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
}
