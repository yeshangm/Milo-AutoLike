package com.example.autolike;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    EditText xInput, yInput, speedInput, minutesInput;
    TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this);
        title.setText("直播自动点赞");
        title.setTextSize(24);
        root.addView(title);

        root.addView(note("仅在你主动启动时运行。先开启无障碍服务和悬浮窗权限。"));
        xInput = field(root, "点赞位置 X（屏幕像素）", "900");
        yInput = field(root, "点赞位置 Y（屏幕像素）", "1500");
        speedInput = field(root, "点击频率（次/秒，建议 1–5）", "3");
        minutesInput = field(root, "运行时长（分钟，最多 60）", "30");

        Button accessibility = new Button(this);
        accessibility.setText("① 开启无障碍服务");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        Button overlay = new Button(this);
        overlay.setText("② 授予悬浮窗权限");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else Toast.makeText(this, "悬浮窗权限已开启", Toast.LENGTH_SHORT).show();
        });
        root.addView(overlay);

        Button launch = new Button(this);
        launch.setText("③ 显示悬浮圆点");
        launch.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_LONG).show(); return;
            }
            int x = number(xInput, 900, 0, 10000);
            int y = number(yInput, 1500, 0, 10000);
            int speed = number(speedInput, 3, 1, 5);
            int mins = number(minutesInput, 30, 1, 60);
            LikeAccessibilityService.config(x, y, speed, mins);
            startService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "悬浮圆点已显示，可拖动位置", Toast.LENGTH_SHORT).show();
        });
        root.addView(launch);
        status = note("提示：坐标以屏幕左上角为原点。请先用手机分辨率/开发者工具确认点赞区域坐标。");
        root.addView(status);
        setContentView(root);
    }

    TextView note(String s) { TextView t = new TextView(this); t.setText(s); t.setTextSize(14); t.setPadding(0,16,0,16); return t; }
    EditText field(LinearLayout root, String hint, String value) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setText(value);
        root.addView(e); return e;
    }
    int number(EditText e, int d, int min, int max) {
        try { return Math.max(min, Math.min(max, Integer.parseInt(e.getText().toString().trim()))); }
        catch(Exception ex) { return d; }
    }
}
